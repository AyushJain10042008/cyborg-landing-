# AUGMENTA — Cyborg Landing Page

A responsive, cyborg-themed landing page for a fictional augmentation brand. Pure HTML, CSS and vanilla JavaScript — no frameworks, no build step, no dependencies beyond Google Fonts.

> AUGMENTA is a fictional brand created for a design concept. The waitlist form is a demo: it validates in the browser and sends nothing anywhere.

## Highlights
- **HUD hero** — an animated SVG cyborg eye whose pupil tracks your cursor, with live telemetry, a glitch headline and a falling data-rain canvas
- **Six systems** — chamfered cards with scan-line hover effects and inline SVG icons
- **Upgrade configurator** — toggle five modules (or click hotspots on the body diagram) and watch the stats, body glow and "machine %" ring update
- **Human vs cyborg slider** — drag or use arrow keys to reveal the specs
- **Terminal boot log** typed on scroll, pricing tiers, accessible FAQ accordion
- **Waitlist form** with validation and a generated operator ID
- Magnetic buttons, cursor glow, marquee, count-up stats

## Responsive & accessible
Fluid layouts from 320px to ultrawide, a full-screen mobile menu, keyboard-operable controls, `aria-live` regions, a skip link, and `prefers-reduced-motion` support.

## Run locally
```bash
python3 -m http.server 8000   # or: npx serve .
```
Open http://localhost:8000 (or simply open `index.html`).

## Deploy to GitHub Pages
Push to `main`, then **Settings → Pages → Source: GitHub Actions**. The included workflow publishes the site.

## Structure
```
index.html      markup
css/style.css   styles
js/main.js      interactions + content data
```

## License
MIT © Ayush Jain
