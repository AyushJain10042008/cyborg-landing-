/* ==========================================================
   AUGMENTA — cyborg landing page · vanilla JS
   ========================================================== */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(pointer: fine)').matches;

  /* ---------------- content ---------------- */
  const FEATURES = [
    { n: 'Neural Link', k: 'LATENCY 0.4 ms', d: 'A lace of nano-filaments that syncs thought to silicon. Recall anything, learn anything, think at machine tempo.',
      i: '<circle cx="24" cy="24" r="6"/><circle cx="8" cy="10" r="3"/><circle cx="40" cy="12" r="3"/><circle cx="9" cy="38" r="3"/><circle cx="40" cy="38" r="3"/><path d="M11 12l9 8M37 14l-8 6M12 36l8-8M37 36l-8-8"/>' },
    { n: 'Optic HUD', k: 'SPECTRUM 380–2500 nm', d: 'Multi-spectrum vision with a live overlay: thermal, night, zoom and threat-tracking, rendered straight onto the retina.',
      i: '<path d="M3 24q21-24 42 0-21 24-42 0z"/><circle cx="24" cy="24" r="7"/><circle cx="24" cy="24" r="2" fill="currentColor"/>' },
    { n: 'Titanium Frame', k: 'LOAD 2,000 kg', d: 'A lattice-printed endoskeleton, bonded to bone. Lighter than steel, harder than anything you have broken.',
      i: '<path d="M24 4l16 9v22l-16 9-16-9V13z"/><path d="M24 4v40M8 13l32 22M40 13L8 35"/>' },
    { n: 'Synth Muscle', k: 'RESPONSE 8 ms', d: 'Electro-active fibres that contract on demand. Sprint, climb and carry without the lactic burn.',
      i: '<path d="M3 24h9l4-13 8 26 8-19 4 6h9"/>' },
    { n: 'Bio-Shield', k: 'THREAT FILTER 99.97%', d: 'An adaptive immune layer that learns pathogens in minutes and quarantines anything that should not be inside you.',
      i: '<path d="M24 4l16 6v12c0 10-7 18-16 22C15 40 8 32 8 22V10z"/><path d="M16 24l6 6 11-13"/>' },
    { n: 'Quantum Core', k: 'POWER 14 days / charge', d: 'A palm-sized power and compute heart. Keeps every module alive, and keeps you running through the week.',
      i: '<circle cx="24" cy="24" r="3" fill="currentColor"/><ellipse cx="24" cy="24" rx="20" ry="8"/><ellipse cx="24" cy="24" rx="20" ry="8" transform="rotate(60 24 24)"/><ellipse cx="24" cy="24" rx="20" ry="8" transform="rotate(120 24 24)"/>' }
  ];

  const BASE = { str: 30, spd: 30, vis: 30, int: 40, res: 30 };
  const STAT_NAMES = { str: 'Strength', spd: 'Speed', vis: 'Vision', int: 'Intellect', res: 'Resilience' };
  const MODS = [
    { id: 'neural', n: 'Neural Link', d: { int: 35, vis: 5 } },
    { id: 'optic', n: 'Optic HUD', d: { vis: 40 } },
    { id: 'core', n: 'Quantum Core', d: { res: 20, int: 10, spd: 10 } },
    { id: 'arms', n: 'Titanium Arms', d: { str: 40, res: 10 } },
    { id: 'legs', n: 'Servo Legs', d: { spd: 40, str: 10 } }
  ];

  const CMP = [
    ['Reaction time', '250 ms', '8 ms'],
    ['Lifting capacity', '100 kg', '2,000 kg'],
    ['Vision', 'Visible light', '380–2500 nm'],
    ['Memory', 'Forgets names', '2 PB, indexed'],
    ['Stamina', '8 hours', '14 days']
  ];

  const PLANS = [
    { n: 'Initiate', p: '0', u: 'cr', f: ['Waitlist priority', 'Virtual upgrade preview', 'Community channel'], b: 'Start free' },
    { n: 'Operator', p: '49', u: 'cr / month', f: ['Two module slots', 'Quarterly firmware', 'Priority calibration', 'Bio-Shield basic'], b: 'Choose Operator', hot: true },
    { n: 'Sovereign', p: 'Custom', u: '', f: ['All five modules', 'Dedicated engineer', 'Lifetime firmware', 'Full Bio-Shield'], b: 'Talk to us' }
  ];

  const FAQ = [
    ['Is any of this real?', 'No. AUGMENTA is a fictional brand created for a landing-page design concept. There are no implants, no prices and no product.'],
    ['Is an upgrade reversible?', 'In the fiction, every module is hot-swappable and removable. In reality, please keep your original parts.'],
    ['Will it work with my existing implants?', 'Our fictional engineers say yes. Our real ones are busy making this page responsive on your phone.'],
    ['Do you store my email?', 'No. The waitlist form is a demo: it validates the address in your browser and sends nothing anywhere.']
  ];

  const TERM = [
    ['> boot augmenta.core --version 9.4.1', ''],
    ['[ OK ] neural link ............ synced', 'ok'],
    ['[ OK ] optic hud .............. calibrated', 'ok'],
    ['[WARN] human hesitation ....... detected', 'wn'],
    ['[ OK ] hesitation ............. patched', 'ok'],
    ['> welcome, operator. you are 100% upgradable.', 'pk']
  ];

  /* ---------------- nav ---------------- */
  const nav = $('#nav'), links = $('#links'), burger = $('#burger');
  const onScroll = () => nav.classList.toggle('stuck', scrollY > 24);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  burger.addEventListener('click', () => { const o = links.classList.toggle('open'); burger.setAttribute('aria-expanded', o); });
  $$('a', links).forEach(a => a.addEventListener('click', () => { links.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); }));

  /* ---------------- pointer: glow, magnetic buttons, eye ---------------- */
  const glow = $('.glow'), pupil = $('#pupil'), eye = $('#eye');
  if (fine) document.documentElement.classList.add('has-glow');
  addEventListener('pointermove', e => {
    if (fine) glow.style.transform = `translate(${e.clientX}px,${e.clientY}px)`;
    if (!reduce) {
      const r = eye.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const dx = e.clientX - cx, dy = e.clientY - cy, d = Math.hypot(dx, dy) || 1, k = Math.min(1, d / 400) * 20;
      pupil.style.transform = `translate(${(dx / d) * k}px,${(dy / d) * k}px)`;
    }
  }, { passive: true });
  if (fine && !reduce) $$('.mag').forEach(el => {
    el.addEventListener('pointermove', e => { const r = el.getBoundingClientRect(); el.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.2}px,${(e.clientY - r.top - r.height / 2) * 0.25}px)`; });
    el.addEventListener('pointerleave', () => { el.style.transform = ''; });
  });

  // eye telemetry + glitch
  const focusEl = $('#focus'), threat = $('#threat'), gl = $('.glitch');
  setInterval(() => { focusEl.textContent = (0.88 + Math.random() * 0.11).toFixed(2); }, 900);
  const threats = ['CLEAR', 'CLEAR', 'SCANNING', 'CLEAR', 'LOCKED'];
  let ti = 0; setInterval(() => { threat.textContent = threats[++ti % threats.length]; }, 2400);
  if (!reduce) {
    const fire = () => { gl.classList.remove('fire'); void gl.offsetWidth; gl.classList.add('fire'); };
    setTimeout(fire, 700); setInterval(fire, 6000);
  }

  /* ---------------- data rain canvas ---------------- */
  const cv = $('#rain'), ctx = cv.getContext('2d');
  let cols = [], fs = 16, rw = 0, rh = 0;
  function sizeRain() {
    const dpr = Math.min(devicePixelRatio || 1, 1.5);
    rw = innerWidth; rh = innerHeight; fs = rw < 700 ? 18 : 16;
    cv.width = rw * dpr; cv.height = rh * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    cols = Array.from({ length: Math.ceil(rw / fs) }, () => Math.random() * rh / fs);
  }
  sizeRain(); addEventListener('resize', sizeRain);
  const glyphs = '01ABCDEF<>/\\+=';
  let last = 0;
  function rain(now) {
    requestAnimationFrame(rain);
    if (document.hidden || now - last < 60) return; last = now;
    ctx.fillStyle = 'rgba(5,7,13,.16)'; ctx.fillRect(0, 0, rw, rh);
    ctx.font = fs + 'px "Share Tech Mono",monospace';
    for (let i = 0; i < cols.length; i++) {
      if (Math.random() > 0.55) { cols[i] += 1; continue; }
      ctx.fillStyle = Math.random() > 0.96 ? '#ff2e88' : '#00e5ff';
      ctx.fillText(glyphs[(Math.random() * glyphs.length) | 0], i * fs, cols[i] * fs);
      if (cols[i] * fs > rh && Math.random() > 0.975) cols[i] = 0; else cols[i] += 1;
    }
  }
  if (!reduce) requestAnimationFrame(rain);

  /* ---------------- features ---------------- */
  const fg = $('#featGrid');
  FEATURES.forEach((f, i) => {
    const a = document.createElement('article'); a.className = 'fc rv'; a.style.setProperty('--d', (i % 3) * 0.08 + 's');
    a.innerHTML = `<span class="n">0${i + 1}</span><svg viewBox="0 0 48 48" aria-hidden="true">${f.i}</svg><h3></h3><p></p><span class="k"></span>`;
    $('h3', a).textContent = f.n; $('p', a).textContent = f.d; $('.k', a).textContent = f.k; fg.appendChild(a);
  });

  /* ---------------- configurator ---------------- */
  const modsEl = $('#mods'), statsEl = $('#stats'), ringFg = $('#ringFg'), machPct = $('#machPct');
  const on = new Set();
  MODS.forEach(m => {
    const b = document.createElement('button'); b.className = 'mod'; b.dataset.m = m.id; b.setAttribute('aria-pressed', 'false');
    const dl = Object.entries(m.d).map(([k, v]) => `${STAT_NAMES[k]} +${v}`).join(' · ');
    b.innerHTML = `<span class="sw"></span><span><b></b><small></small></span><span class="d"></span>`;
    $('b', b).textContent = m.n; $('small', b).textContent = dl; $('.d', b).textContent = 'INSTALL';
    b.addEventListener('click', () => toggle(m.id)); modsEl.appendChild(b);
  });
  Object.keys(BASE).forEach(k => {
    const d = document.createElement('div'); d.className = 'st'; d.dataset.k = k;
    d.innerHTML = `<span>${STAT_NAMES[k]}</span><span class="bar"><i></i><u></u></span><output>0</output>`; statsEl.appendChild(d);
  });
  function render() {
    const val = { ...BASE };
    MODS.forEach(m => { if (on.has(m.id)) for (const k in m.d) val[k] += m.d[k]; });
    $$('.st', statsEl).forEach(r => {
      const k = r.dataset.k, v = clamp(val[k], 0, 100);
      $('i', r).style.width = v + '%'; $('u', r).style.width = BASE[k] + '%'; $('output', r).textContent = v;
    });
    const pct = on.size / MODS.length;
    ringFg.style.strokeDashoffset = (314.16 * (1 - pct)).toFixed(1);
    machPct.textContent = Math.round(pct * 100) + '%';
    $$('.mod', modsEl).forEach(b => { const o = on.has(b.dataset.m); b.setAttribute('aria-pressed', o); $('.d', b).textContent = o ? 'ACTIVE' : 'INSTALL'; });
    $$('.part').forEach(p => p.classList.toggle('on', on.has(p.dataset.m)));
    $$('.spot').forEach(p => p.classList.toggle('on', on.has(p.dataset.m)));
  }
  function toggle(id) { on.has(id) ? on.delete(id) : on.add(id); render(); }
  $$('.spot').forEach(s => s.addEventListener('click', () => toggle(s.dataset.m)));
  $('#pHuman').addEventListener('click', () => { on.clear(); render(); });
  $('#pMax').addEventListener('click', () => { MODS.forEach(m => on.add(m.id)); render(); });
  render();

  /* ---------------- compare slider ---------------- */
  const cmp = $('#cmp'), range = $('#cmpRange'), cmpH = $('#cmpH'), cmpC = $('#cmpC');
  CMP.forEach(([l, h, c]) => {
    cmpH.insertAdjacentHTML('beforeend', `<li><span>${l}</span><span>${h}</span></li>`);
    cmpC.insertAdjacentHTML('beforeend', `<li><span>${l}</span><span>${c}</span></li>`);
  });
  range.addEventListener('input', () => cmp.style.setProperty('--p', range.value + '%'));

  /* ---------------- plans + faq ---------------- */
  const pg = $('#planGrid');
  PLANS.forEach((p, i) => {
    const a = document.createElement('article'); a.className = 'plan rv' + (p.hot ? ' hot' : ''); a.style.setProperty('--d', i * 0.08 + 's');
    a.innerHTML = `${p.hot ? '<span class="badge">MOST POPULAR</span>' : ''}<h3></h3><div class="price"></div><ul></ul><a class="btn ${p.hot ? '' : 'ghost'}" href="#join"></a>`;
    $('h3', a).textContent = p.n;
    $('.price', a).innerHTML = `${p.p}${p.u ? ` <small>${p.u}</small>` : ''}`;
    p.f.forEach(t => { const li = document.createElement('li'); li.textContent = t; $('ul', a).appendChild(li); });
    $('.btn', a).textContent = p.b; pg.appendChild(a);
  });
  const fl = $('#faqList');
  FAQ.forEach(([q, a]) => {
    const d = document.createElement('details'); d.innerHTML = '<summary></summary><p></p>';
    $('summary', d).textContent = q; $('p', d).textContent = a;
    d.addEventListener('toggle', () => { if (d.open) $$('details', fl).forEach(o => { if (o !== d) o.open = false; }); });
    fl.appendChild(d);
  });
  $('details', fl).open = true;

  /* ---------------- terminal ---------------- */
  const out = $('#termOut'); let typed = false;
  function typeTerm() {
    if (typed) return; typed = true;
    const caret = out; // pre has ::after caret
    if (reduce) { TERM.forEach(([t, c]) => { const s = document.createElement('span'); s.className = c; s.textContent = t + '\n'; caret.appendChild(s); }); return; }
    let li = 0;
    (function nextLine() {
      if (li >= TERM.length) return;
      const [t, c] = TERM[li++], s = document.createElement('span'); s.className = c; caret.appendChild(s);
      let ci = 0;
      (function ch() { s.textContent = t.slice(0, ++ci); if (ci < t.length) setTimeout(ch, 16); else { s.textContent += '\n'; setTimeout(nextLine, 260); } })();
    })();
  }

  /* ---------------- reveal + counters ---------------- */
  function countUp(el) {
    const end = parseFloat(el.dataset.count), dec = +(el.dataset.dec || 0), suf = el.dataset.suf || '';
    const fmt = v => (dec ? v.toFixed(dec) : Math.round(v).toLocaleString('en-US')) + suf;
    if (reduce) { el.textContent = fmt(end); return; }
    const t0 = performance.now();
    (function step(now) { const p = clamp((now - t0) / 1600, 0, 1); el.textContent = fmt(end * (1 - Math.pow(1 - p, 4))); if (p < 1) requestAnimationFrame(step); })(t0);
  }
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    e.target.classList.add('in'); io.unobserve(e.target);
    if (e.target.classList.contains('term')) typeTerm();
  }), { threshold: 0.15 });
  $$('.rv').forEach(el => io.observe(el));
  const io2 = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { $$('[data-count]', e.target).forEach(countUp); io2.disconnect(); } }), { threshold: 0.3 });
  io2.observe($('.mini'));

  /* ---------------- form ---------------- */
  const form = $('#form'), email = $('#email'), msg = $('#msg');
  form.addEventListener('submit', e => {
    e.preventDefault();
    const v = email.value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) {
      email.classList.remove('bad'); void email.offsetWidth; email.classList.add('bad');
      msg.className = 'msg err'; msg.textContent = 'ERROR — enter a valid email address.'; email.focus(); return;
    }
    email.classList.remove('bad');
    const id = 'AUG-' + Math.random().toString(36).slice(2, 6).toUpperCase();
    msg.className = 'msg ok'; msg.textContent = `ACCESS GRANTED — operator ID ${id}. (Demo only: nothing was sent.)`;
    form.reset();
  });
})();
